. ./utils.sh

oc delete po -n $NAMESPACE_REPORTER $(oc get po -n $NAMESPACE_REPORTER | grep ibm-license-service-reporter-ibm-lsr-instance | awk '{ print $1 }')




    


