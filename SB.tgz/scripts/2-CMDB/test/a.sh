oc delete WebSphereLibertyApplication itsm

cat << EOF | oc apply -f -

apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: itsm-db
  namespace: reporter
spec:
  accessModes:
  - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
  storageClassName: ocs-external-storagecluster-ceph-rbd
  volumeMode: Filesystem
---
apiVersion: liberty.websphere.ibm.com/v1
kind: WebSphereLibertyApplication
metadata:
  name: itsm
  namespace: reporter
spec:
  license:
    accept: true
    edition: IBM WebSphere Application Server Liberty Core
    productEntitlementSource: IBM Cloud Pak for Applications
  applicationVersion: v2
  topologySpreadConstraints:
    constraints:
      - labelSelector:
          matchLabels:
            app.kubernetes.io/instance: zone
        maxSkew: 1
        topologyKey: kubernetes.io/hostname
        whenUnsatisfiable: ScheduleAnyway
  securityContext:
    runAsNonRoot: true
    readOnlyRootFilesystem: false
  serviceAccount:
    mountToken: true
  autoscaling:
    minReplicas: 1
    maxReplicas: 2
    targetCPUUtilizationPercentage: 60
  applicationImage: image-registry.openshift-image-registry.svc:5000/reporter/itsm:v1
  expose: true
  manageTLS: true
  replicas: 1
  pullPolicy: Always
  manageLTPA: false
  volumeMounts:
    - mountPath: /opt/ibm/wlp/output/defaultServer
      name: db
  volumes:
  - name: db
    persistentVolumeClaim:
      claimName: itsm-db
EOF
