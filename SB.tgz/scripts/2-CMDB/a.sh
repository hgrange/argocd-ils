ho=$(oc get route itsm -n reporter -o jsonpath='{.spec.host}')
curl -v -X 'POST' https://$ho/v2/cmdb -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"sid": "cluster1_app13", "cluster": "Cluster1","namespace":"ibm_licensing","project": "app13", "ownerEmail": "carine@bnp.com"}'


