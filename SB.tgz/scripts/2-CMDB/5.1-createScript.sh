 cat 1-createCMDB.sh | grep curl | awk -F\" '{ print "insert into APP.CMDB values (\047"$4"\047,\047"$8"\047,\047"$12"\047,\047"$20"\047,\047"$16"\047);"}'

