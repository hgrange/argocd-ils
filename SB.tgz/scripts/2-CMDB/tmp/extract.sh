oc cp $1:/data/logs/$2 $2
fi=$(echo $2 | sed 's/.log.gz//')
gzip -d -c $2 | grep 'rec=' |grep '"id":2,' | tail -1 | awk -F\' '{ print $2 }' | jq . > $fi.json
