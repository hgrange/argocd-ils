 oc port-forward -n reporter $(oc get po -n reporter -l app.kubernetes.io/instance=itsm -o jsonpath='{.items[].metadata.name}')  9080
