. ./env.sh

ho=$(oc get route itsm  -n $NAMESPACE_REPORTER -o jsonpath='{.spec.host}')
curl  -k -v -X 'GET' https://$ho/v2/incidents -H 'accept:  application/json' -H 'Content-Type: application/json' 
#curl  -k -X -v 'GET' https://$ho/v2/incidents -H 'accept:  application/json' -H 'Content-Type: application/json' | jq
#curl  -X 'GET' 'http://192.168.14.25:9080/v2/incidents' -H 'accept:  application/json' -H 'Content-Type: application/json' | jq
