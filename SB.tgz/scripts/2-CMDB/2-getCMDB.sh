COOKIE="`pwd`/cookie.jar"


url=https://$(oc get route itsm -n reporter -o jsonpath='{.spec.host}')
#url=http://localhost:9080
TKN=$(cat .access_token)
#curl -v -k -X 'GET' --cookie "$COOKIE" --cookie-jar "$COOKIE" "$url/v2/cmdbs" -H 'accept: application/json' -H 'Content-Type: application/json' -H 'Authorization: Bearer $TKN'
curl -v -k -X 'GET'  "$url/v2/cmdbs" -H 'accept: application/json' -H 'Content-Type: application/json' -H "Authorization: Bearer $TKN"
