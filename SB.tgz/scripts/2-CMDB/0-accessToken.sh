#!/bin/bash

init()
{
#KEYCLOAK_URL="http://localhost:8080"
KEYCLOAK_URL=https://$(oc get route keycloak -o jsonpath='{.spec.host}')
REDIRECT_URL="http://localhost:8080"
REDIRECT_URL=$KEYCLOAK_URL                                                                                                      
USERNAME="alice"
PASSWORD="BobpwdBobpwdBobpwd"
USERNAME="bob"
PASSWORD="Frapoticp4aFrapoticp4a"
REALM="openliberty"
CLIENTID="reporter"
CLIENT_SECRET="boPKDWXSZXU9Xcvied3KBjoA3zkLgsYN"
}

decode() {
  jq -R 'split(".") | .[1] | @base64d | fromjson' <<< $1
}

echo " "


init

COOKIE="`pwd`/cookie.jar"

> cookie.jar
#curl -vSL  --get --cookie "$COOKIE" --cookie-jar "$COOKIE" \
AUTHENTICATE_URL=$(curl -k -sSL  --get --cookie "$COOKIE" --cookie-jar "$COOKIE" \
  --header 'Content-Type: application/x-www-form-urlencoded' \
  --data-urlencode "client_id=${CLIENTID}" \
  --data-urlencode "redirect_uri=${REDIRECT_URL}" \
  --data-urlencode "scope=openid" \
  --data-urlencode "response_type=code" \
  --data-urlencode "response_mode=query" \
  --data-urlencode "client_secret=${CLIENT_SECRET}" \
  --data-urlencode "state=fj8o3n7bdy1op5" \
  "$KEYCLOAK_URL/realms/$REALM/protocol/openid-connect/auth" | tr ' ' '\12' |grep action= | sed 's/action=//' | sed 's/"//g') 
#  "$KEYCLOAK_URL/realms/$REALM/protocol/openid-connect/auth" | tr ' ' '\12' |grep action= | sed 's/action=//' | sed 's/"//g' 
#  --header 'Content-Type: application/x-www-form-urlencoded' \
#  --data-urlencode "state=fj8o3n7bdy1op5" \






AUTHENTICATE_URL=`echo $AUTHENTICATE_URL  | sed -e 's/\&amp;/\&/g'`

echo "Sending Username Password to following authentication URL of keycloak : $AUTHENTICATE_URL"

echo " "

#curl -sSL --cookie "$COOKIE" --cookie-jar "$COOKIE" \
CODE_URL=$(curl -k -sS --cookie "$COOKIE" --cookie-jar "$COOKIE" \
  --data-urlencode "username=$USERNAME" \
  --data-urlencode "password=$PASSWORD" \
  --write-out "%{REDIRECT_URL}" \
 $AUTHENTICATE_URL)
#  $AUTHENTICATE_URL 
#  --write-out "%{REDIRECT_URL}" \

echo "Following URL with code received from Keycloak : $CODE_URL"
echo " "
code=`echo $CODE_URL | awk -F "code=" '{print $2}' | awk '{print $1}'`

echo "Extracted code : $code"
echo " "
echo " "
echo "Sending code=$code to Keycloak to receive Access token"
echo " "
> cookie.jar
ACCESS_TOKEN=$(curl -k -sS --cookie "$COOKIE" --cookie-jar "$COOKIE" \
  --header 'Content-Type: application/x-www-form-urlencoded' \
  --data-urlencode "client_id=$CLIENTID" \
  --data-urlencode "client_secret=${CLIENT_SECRET}" \
  --data-urlencode "redirect_uri=$REDIRECT_URL" \
  --data-urlencode "code=$code" \
  --data-urlencode "grant_type=authorization_code" \
  "$KEYCLOAK_URL/realms/$REALM/protocol/openid-connect/token" \
  | jq -r ".access_token")

echo "access token : $ACCESS_TOKEN" 
echo $ACCESS_TOKEN > .access_token
echo " "

echo "Decoded Access Token: "
decode $ACCESS_TOKEN


#  "$KEYCLOAK_URL/realms/$REALM/protocol/openid-connect/token" \
#  | jq -r ".access_token")
#  "$KEYCLOAK_URL/realms/$REALM/protocol/openid-connect/token" \
#  http://192.168.184.131:9084/hooks/topology)
#  --header 'Content-Type: application/x-www-form-urlencoded' \

echo "Validate Token :"
curl -k -sS --cookie "$COOKIE" --cookie-jar "$COOKIE" -v \
  --header 'Content-Type: application/x-www-form-urlencoded' \
  --data-urlencode "client_id=$CLIENTID" \
  --data-urlencode "client_secret=${CLIENT_SECRET}" \
  --data-urlencode "token=$ACCESS_TOKEN" \
  "$KEYCLOAK_URL/realms/$REALM/protocol/openid-connect/token/introspect"


