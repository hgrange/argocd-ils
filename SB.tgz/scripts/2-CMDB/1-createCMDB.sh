ho=$(oc get route itsm -n reporter -o jsonpath='{.spec.host}')
url=http://192.168.153.1:9080
url=https://$ho

curl -k -v -X 'POST' $url/v2/cmdb -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"sid": "cluster1_app1", "cluster": "ClusterTechzone","namespace":"app1","project": "app1", "ownerEmail": "patrick@ibm.com"}'
read
curl -k -v -X 'POST' $url/v2/cmdb -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"sid": "cluster1_app2", "cluster": "ClusterTechzone","namespace":"app2","project": "app2", "ownerEmail": "lucile@bnp.com"}'
curl -k -v -X 'POST' $url/v2/cmdb -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"sid": "cluster1_app3", "cluster": "ClusterTechzone","namespace":"scanner","project": "app3", "ownerEmail": "eric@bnp.com"}'
curl -k -v -X 'POST' $url/v2/cmdb -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"sid": "cluster1_app4", "cluster": "ClusterTechzone","namespace":"cp4i","project": "app4", "ownerEmail": "nacera@bnp.com"}'
curl -k -v -X 'POST' $url/v2/cmdb -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"sid": "cluster1_app5", "cluster": "ClusterTechzone","namespace":"liberty","project": "app5", "ownerEmail": "michael@bnp.com"}'
curl -k -v -X 'POST' $url/v2/cmdb -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"sid": "cluster1_app6", "cluster": "ClusterTechzone","namespace":"ils","project": "app6", "ownerEmail": "herve@ibm.com"}'
curl -k -v -X 'POST' $url/v2/cmdb -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"sid": "cluster1_app7", "cluster": "ClusterTechzone","namespace":"reporter","project": "app7", "ownerEmail": "charles@bnbnpp.com"}'
curl -k -v -X 'POST' $url/v2/cmdb -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"sid": "cluster1_app8", "cluster": "ClusterTechzone","namespace":"rse","project": "app8", "ownerEmail": "didier@bnbnpp.com"}'


