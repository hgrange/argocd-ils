DERBYDIR=/opt/ibm/wlp/usr/shared/resources
DERBYLIB=$DERBYDIR/derby-10.15.1.3.jar:$DERBYDIR/derbyshared-10.15.1.3.jar:$DERBYDIR/derbytools-10.15.1.3.jar
cat << EOF | java -Dij.database="jdbc:derby:/output/db/db1" -cp $DERBYLIB org.apache.derby.tools.ij
show tables;
insert into APP.CMDB values ('cluster1_app1','Cluster1','ils','michael@bnp.com','ils');
insert into APP.CMDB values ('cluster1_app2','Cluster1','reporter','lucile@bnp.com','reporter');
insert into APP.CMDB values ('cluster1_app3','Cluster1','scanner','eric@bnp.com','scanner');
insert into APP.CMDB values ('cluster1_app4','Cluster1','app4','nacera@bnp.com','app4');
insert into APP.CMDB values ('cluster1_app5','Cluster1','liberty','didier@bnp.com','liberty');
insert into APP.CMDB values ('cluster1_app6','Cluster1','app6','charles@bnp.com','app6');
insert into APP.CMDB values ('cluster1_app7','Cluster1','app7','samy@bnp.com','app7');
insert into APP.CMDB values ('cluster1_app8','Cluster1','cp4i','sebastien@bnp.com','cp4i');

exit
EOF

