. ./utils.sh

token=$(get_token)
apihost=$(get_host)

scanner_results() {
cat << EOF
[
    {
        "kind": "Deployment",
        "name": "ibm-websphere-liberty",
        "namespace": "namespace2",
        "replicas": 1,
        "containers": [
            {
                "name": "websphere-liberty",
                "image": "test.registry.com/ibm-websphere-liberty:test",
                "components": [
                    {
                        "id": "0ca5af184810448c851299b2c615ebb6",
                        "name": "Open Liberty",
                        "version": "22.0.0",
                        "installationPath": "opt/ol/wlp/lib/versions/tags/ibm.com_Open_Liberty-22.0.0.swidtag"
                    }
                ]
            }
        ]
    },
    {
        "kind": "Deployment",
        "name": "ibm-mq-advanced",
        "namespace": "namespace1",
        "replicas": 1,
        "containers": [
            {
                "name": "mq-advanced",
                "image": "test.registry.com/ibm-mq-advanced:test",
                "components": [
                    {
                        "id": "79afd716d55b4f149a87bec52c9dc1aa",
                        "name": "IBM MQ",
                        "version": "9.2.5",
                        "installationPath": "opt/mqm/swidtag/ibm.com_IBM_MQ-9.2.5.swidtag"
                    },
                    {
                        "id": "4486e8c4cc9146fd9b3ce1f14a2dfc5b",
                        "name": "IBM MQ Advanced",
                        "version": "9.2.5",
                        "installationPath": "opt/mqm/swidtag/ibm.com_IBM_MQ_Advanced-9.2.5.swidtag"
                    },
                    {
                        "id": "2105326f381d45dc9b4d2cfb63f9058f",
                        "name": "IBM MQ Advanced Message Security",
                        "version": "9.2.5",
                        "installationPath": "opt/mqm/swidtag/ibm.com_IBM_MQ_Advanced_Message_Security-9.2.5.swidtag"
                    },
                    {
                        "id": "69cdce9622dd4e61bfbb3a3f42b7f17d",
                        "name": "IBM MQ Client",
                        "version": "9.2.5",
                        "installationPath": "opt/mqm/swidtag/ibm.com_IBM_MQ_Client-9.2.5.swidtag"
                    }
                ]
            }
        ]
    },
    {
        "kind": "Deployment",
        "name": "webphere-liberty",
        "namespace": "namespace3",
        "replicas": 1,
        "containers": [
            {
                "name": "WebSphere",
                "image": "icr.io/appcafe/websphere-liberty@sha256:0156c62be9217c7e70006da5bd5538dafa46a259d7855d678e50df61706bd09a",
                "components": [
                    {
                        "id": "3e5b4c633588442ba04a89370ebc9832",
                        "name": "WebSphere Application Server Liberty ILAN",
                        "version": "24.0.0.11",
                        "installationPath": "/opt/ibm/wlp/lib/versions/tags/ibm.com_WebSphere_Application_Server_Liberty_ILAN-24.0.0.11.swidtag"
                    },
                    {
                        "id": "3e5b4c633588442ba04a89370ebc9832",
                        "name": "WebSphere Application Server Liberty ILAN",
                        "version": "24.0.0",
                        "installationPath": "/opt/ibm/wlp/lib/versions/tags/ibm.com_WebSphere_Application_Server_Liberty_ILAN-24.0.0.swidtag"
                    }
                ]
            }
        ]
    }
     
]
EOF
}

ls_results() {
cat << EOF
{
    "group-1": [
        {
            "Kind": "Deployment",
            "Name": "ibm-app-connect-enterprise",
            "Namespace": "namespace1",
            "Replicas": 1,
            "Containers": [
                {
                    "Image": "test.registry.com/ibm-app-connect-enterprise:test",
                    "Name": "app-connect-enterprise",
                    "Charged": "True"
                }
            ],
            "Annotations": {
                "productID": "b8b6252aa88b4cd996c4b7aca350d2fe",
                "productName": "IBM App Connect Enterprise",
                "productMetricName": "VIRTUAL_PROCESSOR_CORE",
                "productCloudpakRatio": "1:3",
                "cloudpakId": "c8b82d189e7545f0892db9ef2731b90d",
                "cloudpakName": "IBM Cloud Pak for Integration"
            }
        },
        {
            "Kind": "Deployment",
            "Name": "ibm-db2-standard-edition-vpc-option",
            "Namespace": "namespace1",
            "Replicas": 1,
            "Containers": [
                {
                    "Image": "test.registry.com/ibm-db2-standard-edition-vpc-option:test",
                    "Name": "db2-standard-edition",
                    "Charged": "True"
                }
            ],
            "Annotations": {
                "productID": "237beb0aed3a4083af3e17f37f4b7a15",
                "productName": "IBM Db2 Standard Edition VPC Option",
                "productMetricName": "VIRTUAL_PROCESSOR_CORE"
            }
        },
        {
            "Kind": "Deployment",
            "Name": "ibm-netcool-agile-service-manager",
            "Namespace": "namespace1",
            "Replicas": 1,
            "Containers": [
                {
                    "Image": "test.registry.com/ibm-netcool-agile-service-manager:test",
                    "Name": "netcool-agile-service-manager",
                    "Charged": "True"
                }
            ],
            "Annotations": {
                "productID": "70f4a31681f54ba7b674e4f78b9e0cec",
                "productName": "IBM Netcool Agile Service Manager",
                "productMetricName": "VIRTUAL_PROCESSOR_CORE"
            }
        },
        {
            "Kind": "Deployment",
            "Name": "ibm-operational-decision-manager-containers",
            "Namespace": "namespace1",
            "Replicas": 1,
            "Containers": [
                {
                    "Image": "test.registry.com/ibm-operational-decision-manager-containers-main:test",
                    "Name": "odm-main",
                    "Charged": "True"
                },
                {
                    "Image": "test.registry.com/ibm-operational-decision-manager-containers-proxy:test",
                    "Name": "odm-proxy",
                    "Charged": "False"
                }
            ],
            "Annotations": {
                "productID": "94a9c8c358bb43ba8fbdea62e7e166a5",
                "productName": "IBM Cloud Pak for Business Automation",
                "productMetricName": "VIRTUAL_PROCESSOR_CORE",
                "productCloudpakRatio": "1:5",
                "cloudpakId": "94a9c8c358bb43ba8fbdea62e7e166a5",
                "cloudpakName": "IBM Cloud Pak for Business Automation"
            }
        }
   ]
}
EOF
}

data_condition() {
cat << EOF
{
    "generatedBy": "IBM License Service",
    "serviceVersion": "4.2.11",
    "clusterData": {
        "clusterName": "cluster2",
        "clusterId": "123abc",
        "masterNodeName": "itz-9zfzru-master-1",
        "masterNodeIP": "10.10.10.11",
        "kubeSystemUid": "456def"
    },
    "ibmLicensingDefinitions": [],
    "lsWorkloadsScanDate": "$cdate",
    "scannerScanDate": "$cdate"
}

EOF
}

cdate=$(date +"%Y-%m-%dT%H:%M:%SZ")

data_condition | jq -c > data_condition.json
ls_results | jq -c > ls_results.json
scanner_results | jq -c > scanner_results.json
rm workloads.zip
zip workloads.zip data_condition.json ls_results.json scanner_results.json

curl -i -k -X "PUT"  -H 'Content-Type: multipart/form-data'  https://$apihost/workloads?token=$token -F"file=@$PWD/workloads.zip"
rm workloads.zip data_condition.json ls_results.json scanner_results.json








    


