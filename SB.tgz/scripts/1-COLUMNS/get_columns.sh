. ../utils.sh

token=$(get_token)
apihost=$(get_host)

curl -s -k -X "GET"  -H 'Content-Type: application/json'  https://$apihost/custom_columns?token=$token | jq .




    


