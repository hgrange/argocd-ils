. ../utils.sh

token=$(get_token)
apihost=$(get_host)
   curl -i -k -X "DELETE"  -H 'Content-Type: application/json'  https://$apihost/custom_columns/$1?token=$token 

#oc delete po -n $NAMESPACE_REPORTER $(oc get po -n $NAMESPACE_REPORTER | grep ibm-license-service-reporter-ibm-lsr-instance | awk '{ print $1 }')




    


