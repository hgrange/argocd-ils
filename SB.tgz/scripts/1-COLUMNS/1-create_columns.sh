. ../utils.sh

token=$(get_token)
apihost=$(get_host)


#for column in "TEST ANNOTATION"
for column in "Remediation needed" "SAM Status" "RITM status" "RITM ID"  "Project" "Project Owner" "Comment" "Charged" "RecId" "TEST ANNOTATION" "Date"
do
   curl -i -k -X "POST"  -H 'Content-Type: application/json'  https://$apihost/custom_columns?token=$token \
   -d "{ \"name\":\"$column\", \"type\":\"text\"}" 
   read
done

#oc delete po -n $NAMESPACE_REPORTER $(oc get po -n $NAMESPACE_REPORTER | grep ibm-license-service-reporter-ibm-lsr-instance | awk '{ print $1 }')




    


