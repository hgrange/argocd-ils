. ../utils.sh

token=$(get_token)
apihost=$(get_host)


   curl -i -k -X "POST"  -H 'Content-Type: application/json'  https://$apihost/custom_columns?token=$token \
   -d "{ \"name\":\"$1\", \"type\":\"text\"}" 





    


