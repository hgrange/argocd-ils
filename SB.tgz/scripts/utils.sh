. ./env.sh

get_token() {
oc get  secret ibm-license-service-reporter-token -n $NAMESPACE_REPORTER -o jsonpath='{.data.token}' | base64 -d
}

get_host() {
oc get route ibm-license-service-reporter  -n $NAMESPACE_REPORTER -o jsonpath='{.spec.host }'
}
 


