. ./utils.sh
echo console: https://$(get_host)/license-service-reporter
echo user: $(oc get -n $NAMESPACE_REPORTER secret ibm-license-service-reporter-credentials -o jsonpath='{.data.username}' |base64 -d )
echo password:  $(oc get -n $NAMESPACE_REPORTER secret ibm-license-service-reporter-credentials -o jsonpath='{.data.password}' |base64 -d )
