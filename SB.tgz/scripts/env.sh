export NAMESPACE_ILS=ils
export NAMESPACE_REPORTER=reporter
export NAMESPACE_SCANNER=scanner

