from kubernetes import client, config
from kubernetes.stream import stream


CLEAR_DATABASE_COMMAND = """/bin/psql -U postgres -c 'DELETE FROM raw.bundled_products; \
    DELETE FROM raw.datasource; \
    DELETE FROM raw.hyper_threading; \
    DELETE FROM raw.ibm_licensing_definition_details; \
    DELETE FROM raw.missing_annotations; \
    DELETE FROM raw.products; \
    DELETE FROM raw.services; \
    DELETE FROM aggr.bundled_products; \
    DELETE FROM aggr.bundled_products_daily; \
    DELETE FROM aggr.datasource; \
    DELETE FROM aggr.hyper_threading; \
    DELETE FROM aggr.ibm_licensing_definition_details; \
    DELETE FROM aggr.metrics; \
    DELETE FROM aggr.missing_annotations; \
    DELETE FROM aggr.products; \
    DELETE FROM aggr.products_daily; \
    DELETE FROM aggr.services; \
    DELETE FROM aggr.services_daily; \
    DELETE FROM aggr.thresholds; \
    DELETE FROM classification.ls_containers; \
    DELETE FROM classification.ls_workloads; \
    DELETE FROM classification.ls_annotations; \
    DELETE FROM classification.scanner_containers; \
    DELETE FROM classification.containers; \
    DELETE FROM classification.custom_columns; \
    DELETE FROM classification.ls_workloads_containers; \
    DELETE FROM classification.scanner_components; \
    DELETE FROM classification.scanner_containers_components; \
    DELETE FROM classification.scanner_workloads; \
    DELETE FROM classification.scanner_workloads_containers; \
    DELETE FROM classification.workload_scan_timestamps; \
    DELETE FROM classification.workloads; \
    DELETE FROM classification.workloads_custom_columns_values;'
"""


def clear_lsr_database(
    namespace: str,
    pod_name: str,
):
    try:
        config.load_config()
        kubernetes_api = client.CoreV1Api()

        output = stream(
            kubernetes_api.connect_get_namespaced_pod_exec,
            pod_name,
            namespace,
            command=["/bin/sh", "-c", CLEAR_DATABASE_COMMAND],
            container="database",
            stderr=True,
            stdin=False,
            stdout=True,
            tty=False,
        )
        return f"\n{output.strip()}"
    except client.rest.ApiException as e:
        return f"Exception occurred while executing command in pod: {str(e)}"
