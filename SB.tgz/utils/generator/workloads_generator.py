import zipfile
import json
import requests
import io

LS_RESULTS = {
    "group-1": [
        {
            "Kind": "Deployment",
            "Name": "ibm-app-connect-enterprise",
            "Namespace": "test-namespace",
            "Replicas": 1,
            "Containers": [
                {
                    "Image": "test.registry.com/ibm-app-connect-enterprise:test",
                    "Name": "app-connect-enterprise",
                    "Charged": True,
                }
            ],
            "Annotations": {
                "productID": "b8b6252aa88b4cd996c4b7aca350d2fe",
                "productName": "IBM App Connect Enterprise",
                "productMetricName": "VIRTUAL_PROCESSOR_CORE",
                "productCloudpakRatio": "1:3",
                "cloudpakId": "c8b82d189e7545f0892db9ef2731b90d",
                "cloudpakName": "IBM Cloud Pak for Integration",
            },
        },
        {
            "Kind": "Deployment",
            "Name": "ibm-db2-standard-edition-vpc-option",
            "Namespace": "test-namespace",
            "Replicas": 1,
            "Containers": [
                {
                    "Image": "test.registry.com/ibm-db2-standard-edition-vpc-option:test",
                    "Name": "db2-standard-edition",
                    "Charged": True,
                }
            ],
            "Annotations": {
                "productID": "237beb0aed3a4083af3e17f37f4b7a15",
                "productName": "IBM Db2 Standard Edition VPC Option",
                "productMetricName": "VIRTUAL_PROCESSOR_CORE",
            },
        },
        # {
        #     "Kind": "Deployment",
        #     "Name": "ibm-mq-advanced",
        #     "Namespace": "test-namespace",
        #     "Replicas": 1,
        #     "Containers": [
        #         {
        #             "Image": "test.registry.com/ibm-mq-advanced:test",
        #             "Name": "mq-advanced",
        #             "Charged": True,
        #         }
        #     ],
        #     "Annotations": {
        #         "productID": "c661609261d5471fb4ff8970a36bccea",
        #         "productName": "IBM MQ",
        #         "productMetricName": "VIRTUAL_PROCESSOR_CORE",
        #     },
        # },
        {
            "Kind": "Deployment",
            "Name": "ibm-netcool-agile-service-manager",
            "Namespace": "test-namespace",
            "Replicas": 1,
            "Containers": [
                {
                    "Image": "test.registry.com/ibm-netcool-agile-service-manager:test",
                    "Name": "netcool-agile-service-manager",
                    "Charged": True,
                }
            ],
            "Annotations": {
                "productID": "70f4a31681f54ba7b674e4f78b9e0cec",
                "productName": "IBM Netcool Agile Service Manager",
                "productMetricName": "VIRTUAL_PROCESSOR_CORE",
            },
        },
        {
            "Kind": "Deployment",
            "Name": "ibm-operational-decision-manager-containers",
            "Namespace": "test-namespace",
            "Replicas": 1,
            "Containers": [
                {
                    "Image": "test.registry.com/ibm-operational-decision-manager-containers-main:test",
                    "Name": "odm-main",
                    "Charged": True,
                },
                {
                    "Image": "test.registry.com/ibm-operational-decision-manager-containers-proxy:test",
                    "Name": "odm-proxy",
                    "Charged": False,
                },
            ],
            "Annotations": {
                "productID": "94a9c8c358bb43ba8fbdea62e7e166a5",
                "productName": "IBM Cloud Pak for Business Automation",
                "productMetricName": "VIRTUAL_PROCESSOR_CORE",
                "productCloudpakRatio": "1:5",
                "cloudpakId": "94a9c8c358bb43ba8fbdea62e7e166a5",
                "cloudpakName": "IBM Cloud Pak for Business Automation",
            },
        },
        # {
        #     "Kind": "Deployment",
        #     "Name": "ibm-websphere-liberty",
        #     "Namespace": "test-namespace",
        #     "Replicas": 1,
        #     "Containers": [
        #         {
        #             "Image": "test.registry.com/ibm-websphere-liberty:test",
        #             "Name": "websphere-liberty",
        #             "Charged": True,
        #         }
        #     ],
        #     "Annotations": {
        #         "productID": "87f3487c22f34742a799164f3f3ffa78",
        #         "productName": "IBM WebSphere Application Server Liberty Core",
        #         "productMetricName": "VIRTUAL_PROCESSOR_CORE",
        #     },
        # },
    ]
}

DATA_CONDITION = {
    "generatedBy": "IBM License Service",
    "serviceVersion": "4.2.11",
    "clusterData": {
        "clusterName": "cluster-1",
        "clusterId": "123abc",
        "masterNodeName": "master0.custom-columns.cp.fyre.ibm.com",
        "masterNodeIP": "111.111.111.111",
        "kubeSystemUid": "456def",
    },
    "ibmLicensingDefinitions": [],
    "lsWorkloadsScanDate": "2024-11-21T09:27:10Z",
    "scannerScanDate": "2024-11-21T08:56:06Z",
}

SCANNER_RESULTS = [
    {
        "kind": "Deployment",
        "name": "ibm-websphere-liberty",
        "namespace": "test-namespace",
        "replicas": 1,
        "containers": [
            {
                "name": "websphere-liberty",
                "image": "test.registry.com/ibm-websphere-liberty:test",
                "components": [
                    {
                        "id": "0ca5af184810448c851299b2c615ebb6",
                        "name": "Open Liberty",
                        "version": "22.0.0",
                        "installationPath": "opt/ol/wlp/lib/versions/tags/ibm.com_Open_Liberty-22.0.0.swidtag",
                    }
                ],
            }
        ],
    },
    {
        "kind": "Deployment",
        "name": "ibm-mq-advanced",
        "namespace": "test-namespace",
        "replicas": 1,
        "containers": [
            {
                "name": "mq-advanced",
                "image": "test.registry.com/ibm-mq-advanced:test",
                "components": [
                    {
                        "id": "79afd716d55b4f149a87bec52c9dc1aa",
                        "name": "IBM MQ",
                        "version": "9.2.5",
                        "installationPath": "opt/mqm/swidtag/ibm.com_IBM_MQ-9.2.5.swidtag",
                    },
                    {
                        "id": "4486e8c4cc9146fd9b3ce1f14a2dfc5b",
                        "name": "IBM MQ Advanced",
                        "version": "9.2.5",
                        "installationPath": "opt/mqm/swidtag/ibm.com_IBM_MQ_Advanced-9.2.5.swidtag",
                    },
                    {
                        "id": "2105326f381d45dc9b4d2cfb63f9058f",
                        "name": "IBM MQ Advanced Message Security",
                        "version": "9.2.5",
                        "installationPath": "opt/mqm/swidtag/ibm.com_IBM_MQ_Advanced_Message_Security-9.2.5.swidtag",
                    },
                    {
                        "id": "69cdce9622dd4e61bfbb3a3f42b7f17d",
                        "name": "IBM MQ Client",
                        "version": "9.2.5",
                        "installationPath": "opt/mqm/swidtag/ibm.com_IBM_MQ_Client-9.2.5.swidtag",
                    },
                ],
            }
        ],
    },
]

LS_RESULTS_JSON = json.dumps(LS_RESULTS, indent="  ")
DATA_CONDITION_JSON = json.dumps(DATA_CONDITION, indent="  ")
SCANNER_RESULTS_JSON = json.dumps(SCANNER_RESULTS, indent="  ")


def upload_workloads_snapshot(host: str, token: str):
    zip_buffer = io.BytesIO()

    with zipfile.ZipFile(zip_buffer, "w") as zip_file:
        zip_file.writestr("data_condition.json", DATA_CONDITION_JSON)
        zip_file.writestr("ls_results.json", LS_RESULTS_JSON)
        zip_file.writestr("scanner_results.json", SCANNER_RESULTS_JSON)

    zip_buffer.seek(0)

    zip_file = {"file": ("workloads.zip", zip_buffer, "application/zip")}

    response = requests.put(
        f"https://{host}/workloads?token={token}", files=zip_file, verify=False
    )

    status_code = response.status_code

    if status_code // 100 == 2:
        return response
    else:
        raise Exception(f"status code: {status_code}")
