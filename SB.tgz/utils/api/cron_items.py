from utils.api.api_manager import APIManager

# HOST = "ibm-license-service-reporter-ibm-ls-reporter.apps.custom-columns-automation.cp.fyre.ibm.com"
# TOKEN = "JtqMdEQoV5FSUkkkT8VxKWBQ"


class Simulator:
    def __init__(self, host: str, token: str):
        self.HOST: str = host
        self.TOKEN: str = token
        self.API_MANAGER = APIManager(host, token)
        self.salesforce_ticket_number = 7890327803

    def append_custom_columns(self):
        self.SAM_STATUS_ID: int = self.API_MANAGER.create_custom_column("SAM Status", "text")["id"]
        self.SALESFORCE_STATUS_ID: int = self.API_MANAGER.create_custom_column("Salesforce status", "text")["id"]
        self.SALESFORCE_TICKET_ID: int = self.API_MANAGER.create_custom_column("Salesforce ticket", "text")["id"]
        self.COMMENT_ID: int = self.API_MANAGER.create_custom_column("Comment", "text")["id"]
        self.REMEDIATION_NEEDED_ID: int = self.API_MANAGER.create_custom_column("Remediation needed", "text")["id"]

    def set_initial_workloads_as_open(self):
        workloads = self.API_MANAGER.get_workloads()

        for workload in workloads:
            workload_id = workload["id"]
            self.API_MANAGER.set_value(workload_id, self.SAM_STATUS_ID, "Open")

    def create_salesforce_ticket_for_workloads_with_required_remediation(self):
        workloads = self.API_MANAGER.get_workloads()

        for workload in workloads:
            workload_id = workload["id"]
            workload_columns = workload["customColumns"]

            try:
                sam_status = [column["value"] for column in workload_columns if column["id"] == self.SAM_STATUS_ID][0]
            except:
                sam_status = ""

            try:
                remediation_needed = [column["value"] for column in workload_columns if column["id"] == self.REMEDIATION_NEEDED_ID][0]
            except:
                remediation_needed = ""

            try:
                salesforce_ticket = [column["value"] for column in workload_columns if column["id"] == self.SALESFORCE_TICKET_ID][0]
            except:
                salesforce_ticket = ""

            if sam_status == "Open" and remediation_needed.lower().strip() in {"true", "yes"} and salesforce_ticket == "":
                self.API_MANAGER.set_value(workload_id, self.SALESFORCE_TICKET_ID, f"SF{self.salesforce_ticket_number}")
                self.salesforce_ticket_number += 1
                self.API_MANAGER.set_value(workload_id, self.SALESFORCE_STATUS_ID, "Open")

    def close_one_service_ticket(self):
        workloads = self.API_MANAGER.get_workloads()

        for workload in workloads:
            workload_id = workload["id"]
            workload_columns = workload["customColumns"]

            try:
                salesforce_status = [column["value"] for column in workload_columns if column["id"] == self.SALESFORCE_STATUS_ID][0]
            except:
                salesforce_status = ""

            if len(workload_columns) < 3:
                print ("IntroA")
            elif salesforce_status == "Open":
                print ("IntroC")
                self.API_MANAGER.set_value(workload_id, self.SALESFORCE_STATUS_ID, "Closed")
                return




# Old functions:
# def append_custom_columns():
#     API_MANAGER = APIManager(HOST, TOKEN)
#     API_MANAGER.create_custom_column("SAM Status", "text")["id"]
#     API_MANAGER.create_custom_column("Salesforce status", "text")["id"]
#     API_MANAGER.create_custom_column("Salesforce ticket", "text")["id"]
#     API_MANAGER.create_custom_column("Comment", "text")["id"]
#     API_MANAGER.create_custom_column("Remediation needed", "text")["id"]

# def set_initial_workloads_as_open():
#     API_MANAGER = APIManager(HOST, TOKEN)
#     custom_columns = API_MANAGER.get_custom_columns()
#     #def set_empty_to_open():
#     _workloads = API_MANAGER.get_workloads()
#     SAM_STATUS_COLUMN_ID = custom_columns[0]["id"]
#     #Filling incoming workloads as opem 
#     for workload in _workloads:
#         workload_id = workload["id"]
#         workload_name = workload["name"]
#         if (len(workload['customColumns'])==0):
#             API_MANAGER.set_value(workload_id, SAM_STATUS_COLUMN_ID, "Open")
#             continue

# def create_salesforce_ticket_for_workloads_with_required_remediation():   
#     #Opening the tickets for deployments requiring remediation
#     API_MANAGER = APIManager(HOST, TOKEN)
#     custom_columns = API_MANAGER.get_custom_columns()
#     SALESFORCE_STATUS_ID = custom_columns[1]["id"]
#     SALESFORCE_TICKET_ID = custom_columns[2]["id"]
#     #def set_empty_to_open():
#     _workloads = API_MANAGER.get_workloads()

#     for workload in _workloads:
#         workload_id = workload["id"]
#         if (1): #define remediation criteria!!!!!!
#             if (SALESFORCE_TICKET_ID in workload['customColumns'][0]):
#                 continue
#         API_MANAGER.set_value(workload_id, SALESFORCE_TICKET_ID, "SF7890327803")
#         API_MANAGER.set_value(workload_id, SALESFORCE_STATUS_ID, "Open")


# def close_one_service_ticket(): 

#     API_MANAGER = APIManager(HOST, TOKEN)
#     _workloads = API_MANAGER.get_workloads()

#     custom_columns = API_MANAGER.get_custom_columns()
#     SALESFORCE_STATUS_ID = custom_columns[1]["id"]
#     SALESFORCE_TICKET_ID = custom_columns[2]["id"]


#     for workload in _workloads:
#         workload_id = workload["id"]
#         workload_name = workload["name"]
#         if (len(workload['customColumns']) < 3):
#             print ("IntroA")
#             continue
#         if (workload['customColumns'][1]['value']=="Open"):
#             print ("IntroC")
#             API_MANAGER.set_value(workload_id, SALESFORCE_STATUS_ID, "Closed")
#             return

    #def set_empty_to_open():
