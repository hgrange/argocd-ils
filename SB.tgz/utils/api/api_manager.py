import requests
import json


class APIManager:
    def __init__(self, host: str, token: str):
        self.host: str = host
        self.token: str = token

    def create_custom_column(self, name: str, data_type: str) -> dict:
        assert data_type in {"text", "number", "date"}

        body = {
            "name": name,
            "type": data_type,
        }

        response = requests.post(
            f"https://{self.host}/custom_columns?token={self.token}",
            json=body,
            verify=False,
        )

        status_code = response.status_code

        if status_code // 100 == 2:
            return response.json()
        else:
            raise Exception(f"status code: {status_code}")

    def delete_custom_column(self, column_id: int) -> dict:
        response = requests.delete(
            f"https://{self.host}/custom_columns/{column_id}?token={self.token}",
            verify=False,
        )

        status_code = response.status_code

        if status_code // 100 == 2:
            return response
        else:
            raise Exception(f"status code: {status_code}")

    def rename_custom_column(self, column_id: int, name: str) -> dict:
        body = {"id": column_id, "name": name}

        response = requests.put(
            f"https://{self.host}/custom_columns/{column_id}?token={self.token}",
            json=body,
            verify=False,
        )

        status_code = response.status_code

        if status_code // 100 == 2:
            return response.json()
        else:
            raise Exception(f"status code: {status_code}")

    def get_custom_column(self, column_id: int) -> dict:
        response = requests.get(
            f"https://{self.host}/custom_columns/{column_id}?token={self.token}",
            verify=False,
        )

        status_code = response.status_code

        if status_code // 100 == 2:
            return response.json()
        else:
            raise Exception(f"status code: {status_code}")

    def get_custom_columns(self) -> list:
        response = requests.get(
            f"https://{self.host}/custom_columns?token={self.token}",
            verify=False,
        )

        status_code = response.status_code

        if status_code // 100 == 2:
            return response.json()
        else:
            raise Exception(f"status code: {status_code}")

    def get_workload(self, workload_id: int) -> dict:
        response = requests.get(
            f"https://{self.host}/workloads/{workload_id}?token={self.token}",
            verify=False,
        )

        status_code = response.status_code

        if status_code // 100 == 2:
            return response.json()
        else:
            raise Exception(f"status code: {status_code}")

    def get_workloads(self) -> list:
        response = requests.get(
            f"https://{self.host}/workloads?token={self.token}",
            verify=False,
        )

        status_code = response.status_code

        if status_code // 100 == 2:
            return response.json()
        else:
            raise Exception(f"status code: {status_code}")

    def set_value(self, workload_id: int, column_id: int, value: float | str) -> dict:
        body = {"value": value}

        response = requests.put(
            f"https://{self.host}/workloads/{workload_id}/custom_columns/{column_id}?token={self.token}",
            json=body,
            verify=False,
        )

        status_code = response.status_code

        if status_code // 100 == 2:
            return response.json()
        else:
            raise Exception(f"status code: {status_code}")

    def clear_value(self, workload_id: int, column_id: int) -> dict:
        response = requests.delete(
            f"https://{self.host}/workloads/{workload_id}/custom_columns/{column_id}?token={self.token}",
            verify=False,
        )

        status_code = response.status_code

        if status_code // 100 == 2:
            return response.json()
        else:
            raise Exception(f"status code: {status_code}")

